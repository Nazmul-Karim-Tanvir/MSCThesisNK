"""Step 2: score every generated QA pair with three filters, then write filtered datasets.
 - blind      : text-only model answers correctly -> language shortcut -> drop
 - consistency: fraction of K different frame samplings whose answer matches -> keep if >= cons_min
 - judge      : model checks (with video) that the answer is correct -> keep if 'yes'
"""
import argparse, os, random
from common import *

ap = argparse.ArgumentParser()
ap.add_argument("--raw", default="data/raw_qa.jsonl")
ap.add_argument("--scored", default="data/scored.jsonl")
ap.add_argument("--k", type=int, default=2)
ap.add_argument("--cons_min", type=float, default=0.5)
ap.add_argument("--select_only", action="store_true", help="skip scoring, just re-apply thresholds")
a = ap.parse_args()

if not a.select_only:
    set_seed(0)
    raw = read_jsonl(a.raw)
    done = {(r["video"], r["question"]) for r in read_jsonl(a.scored)} if os.path.exists(a.scored) else set()
    model, processor = load_model()
    rng = random.Random(0)
    for i, it in enumerate(raw):
        if (it["video"], it["question"]) in done:
            continue
        q, gold = it["question"], it["answer"]
        blind = generate(model, processor, q + ANSWER_SUFFIX, None)
        blind_correct = match(blind, gold)
        hits = 0
        for _ in range(a.k):
            fr = sample_frames(it["video"], jitter=True, rng=rng)
            if len(fr) < 2:
                continue
            hits += match(generate(model, processor, q + ANSWER_SUFFIX, fr), gold)
        cons = hits / a.k
        fr = sample_frames(it["video"])
        judge_prompt = (f"Question: {q}\nProposed answer: {gold}\n"
                        "Based only on the video, is the proposed answer correct? Reply Yes or No.")
        judge = generate(model, processor, judge_prompt, fr, max_new_tokens=3).lower().startswith("yes")
        append_jsonl(a.scored, {**it, "blind_correct": blind_correct, "cons": cons, "judge": judge})
        if (i + 1) % 20 == 0:
            print(f"scored {i+1}/{len(raw)}")

rows = read_jsonl(a.scored)
sets = {
    "no_filter": rows,
    "blind": [r for r in rows if not r["blind_correct"]],
    "cons": [r for r in rows if r["cons"] >= a.cons_min],
    "judge": [r for r in rows if r["judge"]],
    "all": [r for r in rows if (not r["blind_correct"]) and r["cons"] >= a.cons_min and r["judge"]],
}
os.makedirs("data", exist_ok=True)
for name, items in sets.items():
    with open(f"data/train_{name}.jsonl", "w") as f:
        for r in items:
            f.write(json.dumps({"video": r["video"], "question": r["question"], "answer": r["answer"]}) + "\n")
    print(f"{name:10s} {len(items):5d} pairs -> data/train_{name}.jsonl")
