"""Shared helpers: model loading, frame sampling, generation, answer matching."""
import os, re, json, random, string
import torch, cv2
from PIL import Image
from transformers import AutoProcessor
try:
    from transformers import AutoModelForImageTextToText as AutoVLM
except ImportError:
    from transformers import AutoModelForVision2Seq as AutoVLM
from qwen_vl_utils import process_vision_info

# Small model that fits a free GPU. Alternatives: "Qwen/Qwen2-VL-2B-Instruct"
MODEL_ID = os.environ.get("MODEL_ID", "Qwen/Qwen2.5-VL-3B-Instruct")
NUM_FRAMES = int(os.environ.get("NUM_FRAMES", "8"))
FRAME_SIZE = (336, 252)          # both divisible by 28
ANSWER_SUFFIX = " Answer with a short phrase."


def set_seed(s=0):
    random.seed(s); torch.manual_seed(s)


def read_jsonl(path):
    with open(path) as f:
        return [json.loads(l) for l in f if l.strip()]


def append_jsonl(path, obj):
    with open(path, "a") as f:
        f.write(json.dumps(obj) + "\n")


def load_model(adapter=None):
    use_bf16 = torch.cuda.is_available() and torch.cuda.is_bf16_supported()
    dtype = torch.bfloat16 if use_bf16 else torch.float16
    model = AutoVLM.from_pretrained(MODEL_ID, torch_dtype=dtype, device_map="auto")
    processor = AutoProcessor.from_pretrained(MODEL_ID)
    if adapter:
        from peft import PeftModel
        model = PeftModel.from_pretrained(model, adapter)
    model.eval()
    return model, processor


def sample_frames(path, n=NUM_FRAMES, jitter=False, rng=None):
    """Uniformly sample n frames. jitter=True picks a random frame inside each segment."""
    cap = cv2.VideoCapture(path)
    total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    if total <= 0:
        cap.release(); return []
    seg = total / n
    r = rng or random
    frames = []
    for i in range(n):
        idx = int(seg * i + (r.random() * seg if jitter else seg / 2))
        cap.set(cv2.CAP_PROP_POS_FRAMES, min(total - 1, idx))
        ok, fr = cap.read()
        if ok:
            fr = cv2.cvtColor(fr, cv2.COLOR_BGR2RGB)
            frames.append(Image.fromarray(fr).resize(FRAME_SIZE))
    cap.release()
    return frames


def build_inputs(processor, prompt, frames=None, answer=None):
    content = []
    if frames:
        content.append({"type": "video", "video": frames})
    content.append({"type": "text", "text": prompt})
    messages = [{"role": "user", "content": content}]
    text = processor.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
    images, videos = process_vision_info(messages)
    if answer is None:
        return processor(text=[text], images=images, videos=videos, padding=True, return_tensors="pt")
    full = text + answer + "<|im_end|>"
    enc = processor(text=[full], images=images, videos=videos, padding=True, return_tensors="pt")
    p_len = processor(text=[text], images=images, videos=videos, padding=True,
                      return_tensors="pt")["input_ids"].shape[1]
    labels = enc["input_ids"].clone()
    labels[:, :p_len] = -100          # train only on the answer tokens
    enc["labels"] = labels
    return enc


@torch.no_grad()
def generate(model, processor, prompt, frames=None, max_new_tokens=16):
    inputs = build_inputs(processor, prompt, frames).to(model.device)
    out = model.generate(**inputs, max_new_tokens=max_new_tokens, do_sample=False)
    out = out[:, inputs["input_ids"].shape[1]:]
    return processor.batch_decode(out, skip_special_tokens=True)[0].strip()


_ARTICLES = {"a", "an", "the"}

def _norm(s):
    s = s.lower().translate(str.maketrans("", "", string.punctuation))
    return [w for w in s.split() if w not in _ARTICLES]


def match(pred, gold):
    """Lenient answer match (containment or token-F1 >= 0.6). Use the SAME metric for all runs."""
    p, g = _norm(pred), _norm(gold)
    if not p or not g:
        return False
    if p == g or set(g) <= set(p):
        return True
    common = len(set(p) & set(g))
    if common == 0:
        return False
    prec, rec = common / len(set(p)), common / len(set(g))
    return 2 * prec * rec / (prec + rec) >= 0.6
