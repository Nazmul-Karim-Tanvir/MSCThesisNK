"""Step 4: evaluate the base model or a LoRA adapter on data/test.jsonl."""
import argparse, json, os
from common import *

ap = argparse.ArgumentParser()
ap.add_argument("--test", default="data/test.jsonl")
ap.add_argument("--adapter", default=None)
ap.add_argument("--name", required=True)          # e.g. zero_shot, no_filter, all
a = ap.parse_args()

set_seed(0)
test = read_jsonl(a.test)
model, processor = load_model(a.adapter)
correct, n, preds = 0, 0, []
for i, ex in enumerate(test):
    fr = sample_frames(ex["video"])
    if len(fr) < 2:
        continue
    pred = generate(model, processor, ex["question"] + ANSWER_SUFFIX, fr)
    ok = match(pred, ex["answer"])
    correct += ok; n += 1
    preds.append({"q": ex["question"], "gold": ex["answer"], "pred": pred, "ok": bool(ok)})
    if (i + 1) % 50 == 0:
        print(f"{i+1}/{len(test)} acc so far {100*correct/n:.1f}")
acc = 100 * correct / max(n, 1)
os.makedirs("results", exist_ok=True)
json.dump({"name": a.name, "accuracy": acc, "n": n, "preds": preds}, open(f"results/{a.name}.json", "w"), indent=1)
print(f"{a.name}: accuracy {acc:.2f}% on {n} questions")
