"""Convert a benchmark QA json (MSRVTT-QA / MSVD-QA style) into data/test.jsonl.
Adjust --pattern and the field names to match your files."""
import argparse, json, os, random

ap = argparse.ArgumentParser()
ap.add_argument("--qa_json", required=True)          # e.g. test_qa.json
ap.add_argument("--video_dir", required=True)        # folder with test videos
ap.add_argument("--pattern", default="video{video_id}.mp4")
ap.add_argument("--limit", type=int, default=300)
ap.add_argument("--out", default="data/test.jsonl")
a = ap.parse_args()

items = json.load(open(a.qa_json))
random.Random(0).shuffle(items)
os.makedirs(os.path.dirname(a.out), exist_ok=True)
n = 0
with open(a.out, "w") as f:
    for it in items:
        path = os.path.join(a.video_dir, a.pattern.format(**it))
        if not os.path.exists(path):
            continue
        f.write(json.dumps({"video": path, "question": it["question"], "answer": str(it["answer"])}) + "\n")
        n += 1
        if n >= a.limit:
            break
print(f"wrote {n} test questions to {a.out}")
