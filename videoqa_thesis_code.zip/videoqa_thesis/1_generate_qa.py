"""Step 1: unlabeled videos -> captions -> generated QA pairs (no human labels)."""
import argparse, glob, json, os, random, re
from common import *

CAPTION_PROMPT = ("Describe this video in detail in 5-8 sentences, in chronological order. "
                  "Mention people, objects, actions, and the order in which things happen.")

QA_PROMPT = """Below is a description of a video.

Description:
{caption}

Write {n} question-answer pairs that can be answered from this description.
Cover different types: descriptive (what/who/where), counting, temporal (before/after), causal (why/how).
Rules: answers must be 1-4 words; no questions answerable by common knowledge alone.
Return ONLY a JSON list like:
[{{"question": "...", "answer": "...", "type": "descriptive"}}]"""


def parse_qa(text):
    m = re.search(r"\[.*\]", text, re.S)
    if not m:
        return []
    try:
        items = json.loads(m.group(0))
    except Exception:
        return []
    good = []
    for it in items:
        if isinstance(it, dict) and it.get("question") and it.get("answer"):
            if len(str(it["answer"]).split()) <= 6:
                good.append({"question": str(it["question"]).strip(),
                             "answer": str(it["answer"]).strip(),
                             "type": str(it.get("type", "unknown"))})
    return good


ap = argparse.ArgumentParser()
ap.add_argument("--video_dir", default="data/videos_unlabeled")
ap.add_argument("--n_videos", type=int, default=200)
ap.add_argument("--per_video", type=int, default=4)
ap.add_argument("--out", default="data/raw_qa.jsonl")
a = ap.parse_args()

set_seed(0)
os.makedirs(os.path.dirname(a.out), exist_ok=True)
vids = sorted(glob.glob(os.path.join(a.video_dir, "*.mp4")) + glob.glob(os.path.join(a.video_dir, "*.avi")))
random.Random(0).shuffle(vids)
vids = vids[:a.n_videos]
done = {r["video"] for r in read_jsonl(a.out)} if os.path.exists(a.out) else set()

model, processor = load_model()
for i, v in enumerate(vids):
    if v in done:
        continue
    frames = sample_frames(v)
    if len(frames) < 2:
        continue
    caption = generate(model, processor, CAPTION_PROMPT, frames, max_new_tokens=200)
    raw = generate(model, processor, QA_PROMPT.format(caption=caption, n=a.per_video), None, max_new_tokens=500)
    for qa in parse_qa(raw):
        append_jsonl(a.out, {"video": v, "caption": caption, **qa})
    print(f"[{i+1}/{len(vids)}] {os.path.basename(v)}")
print("done ->", a.out)
