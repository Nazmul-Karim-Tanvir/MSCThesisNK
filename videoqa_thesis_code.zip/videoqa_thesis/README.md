# Self-supervised VideoQA: run-today pipeline

Small-scale version of the thesis paper draft. Uses one small open model (default Qwen2.5-VL-3B) for
captioning, QA generation, filtering and answering, so no proprietary model is involved.

NOTE: these scripts were syntax-checked but NOT run (no GPU/internet where they were written).
If a script errors, copy the full error message and ask for a fix. Library versions change often.

## 0. Environment (Colab / Kaggle / lab GPU)
    pip install -U transformers accelerate peft qwen-vl-utils opencv-python pillow
Use a GPU with at least 16 GB. bf16 GPUs (A100, L4, RTX 30/40) are more stable for training than a T4.
Optional: MODEL_ID=Qwen/Qwen2-VL-2B-Instruct (smaller), NUM_FRAMES=6 (faster).

## 1. Data
- Unlabeled pool: put ~200-500 videos (mp4/avi) in `data/videos_unlabeled/`. Their labels are never used.
  Easy option: the TRAIN-split videos of MSRVTT or MSVD (ignore their questions).
- Test set: take TEST-split videos and their QA json (e.g. MSRVTT-QA `test_qa.json`), then:
      python 0_make_test_jsonl.py --qa_json test_qa.json --video_dir path/to/test_videos --limit 300
  Adjust `--pattern` and field names to your files. Make sure no test video is in the unlabeled pool.

## 2. Run, in this order
    python 4_evaluate.py --name zero_shot                      # baseline (Table 1, row 1)
    python 1_generate_qa.py --n_videos 200 --per_video 4       # captions + generated QA
    python 2_filter.py --k 2                                   # scores + writes data/train_*.jsonl
    python 3_train_lora.py --data data/train_no_filter.jsonl --out adapters/no_filter
    python 3_train_lora.py --data data/train_all.jsonl       --out adapters/all
    python 4_evaluate.py --adapter adapters/no_filter --name no_filter
    python 4_evaluate.py --adapter adapters/all       --name all
    python 5_table.py                                          # copy into the paper

Ablations (only if time allows): train and evaluate on `train_blind`, `train_cons`, `train_judge`
the same way. Re-apply thresholds without re-scoring: `python 2_filter.py --select_only --cons_min 0.5`.

## 3. Rough time (200 videos x 4 QA, 300 test questions)
Generation 30-60 min, filtering 1-2 h, each training 10-30 min, each evaluation 10-20 min.
If too slow: fewer videos (`--n_videos 100`), fewer frames, `--limit 150` for the test set.

## 4. Fill the paper draft
- Table 1: zero_shot, no_filter (= "Ours, no filtering"), all (= "Ours, full") on your one benchmark.
  Delete the columns/rows you did not run. Supervised upper bound and Just Ask baseline are only
  needed if you actually ran them.
- Table 3 (ablation): rows for the filter sets you trained; "Data kept" = pair counts printed by 2_filter.py.
- Section 4.3: write the real settings (model, frames, LoRA r=16/alpha=32, lr 1e-4, epochs, GPU).
- Sections you did not do (low-label, scaling curve, self-training rounds, curriculum, per-type):
  remove them or move them to "Future work". Do not leave empty placeholders in the final thesis.

## 5. Things to state honestly in the thesis
- Accuracy uses a lenient string match (containment or token-F1 >= 0.6), not the GPT-judge protocol
  used by published papers, so compare only your own runs to each other.
- The consistency filter keeps questions the model can already partly answer. It removes noise, but
  it can also remove hard questions, which is a trade-off worth discussing.
- 300 test questions gives roughly +/-5 points of noise. Small gains may not be significant; if you have time,
  run a second seed or a larger test set.
- The same model generates, filters and answers, so errors can reinforce themselves (confirmation bias).
