"""Step 5: print all results as a markdown table to copy into the paper."""
import glob, json
rows = [json.load(open(p)) for p in sorted(glob.glob("results/*.json"))]
print("| Method | Accuracy (%) | #Questions |")
print("|---|---|---|")
for r in rows:
    print(f"| {r['name']} | {r['accuracy']:.2f} | {r['n']} |")
