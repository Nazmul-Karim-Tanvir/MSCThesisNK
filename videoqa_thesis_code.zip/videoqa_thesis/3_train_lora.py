"""Step 3: LoRA fine-tune the backbone on a (filtered) generated dataset."""
import argparse, random, torch
from peft import LoraConfig, get_peft_model
from common import *

ap = argparse.ArgumentParser()
ap.add_argument("--data", required=True)          # e.g. data/train_all.jsonl
ap.add_argument("--out", required=True)           # e.g. adapters/all
ap.add_argument("--epochs", type=int, default=1)
ap.add_argument("--lr", type=float, default=1e-4)
ap.add_argument("--accum", type=int, default=8)
a = ap.parse_args()

set_seed(0)
data = read_jsonl(a.data)
model, processor = load_model()
model.config.use_cache = False
model.gradient_checkpointing_enable(gradient_checkpointing_kwargs={"use_reentrant": False})
try:
    model.enable_input_require_grads()
except Exception:
    pass

cfg = LoraConfig(
    r=16, lora_alpha=32, lora_dropout=0.05, task_type="CAUSAL_LM",
    # only the language-model layers (regex avoids the vision tower)
    target_modules=r".*layers\.\d+\.(self_attn|mlp)\.(q_proj|k_proj|v_proj|o_proj|gate_proj|up_proj|down_proj)",
)
model = get_peft_model(model, cfg)
model.print_trainable_parameters()
params = [p for p in model.parameters() if p.requires_grad]
opt = torch.optim.AdamW(params, lr=a.lr, weight_decay=0.0)

model.train()
step = 0
for ep in range(a.epochs):
    random.shuffle(data)
    running = 0.0
    for i, ex in enumerate(data):
        frames = sample_frames(ex["video"], jitter=True)
        if len(frames) < 2:
            continue
        enc = build_inputs(processor, ex["question"] + ANSWER_SUFFIX, frames, answer=ex["answer"]).to(model.device)
        loss = model(**enc).loss / a.accum
        loss.backward()
        running += loss.item() * a.accum
        if (i + 1) % a.accum == 0:
            torch.nn.utils.clip_grad_norm_(params, 1.0)
            opt.step(); opt.zero_grad(); step += 1
            if step % 5 == 0:
                print(f"epoch {ep} step {step} loss {running / (5 * a.accum):.4f}")
                running = 0.0
model.save_pretrained(a.out)
print("saved adapter ->", a.out)
